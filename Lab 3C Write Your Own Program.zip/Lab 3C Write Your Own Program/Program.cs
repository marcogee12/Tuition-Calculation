using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3C_Write_Your_Own_Program
{
    class Program
    {
        static void Main(string[] args)
        {
            Info();
            Console.ReadKey();
        }
        static public double Percentage(double tuition)
        {
            return((tuition / 100) * 2 + tuition);
        }
        static public double Year(double year)
        {
            return (year + 1);
        }
        static void Info()
        {
            Console.WriteLine("Tuition Calculation Over a 5 Year Period.");
            Console.WriteLine("Please enter the current year.");
            double year = Convert.ToDouble(Console.ReadLine());
            double yearcap = year + 4;
            double tuition = 6000;
            for (double i = year; i <= yearcap; i++)
            {
                Console.WriteLine($"For {year}, your tuition will be {tuition:c}");
                year = Year(year);
                tuition = Percentage(tuition);
            }
        }
    }
}
